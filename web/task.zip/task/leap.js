var year = prompt("Enter the year: ");
if(year%4==0){
    document.write("The year is leap year.")
}
else{
    document.write("The year is not leap year.")
}